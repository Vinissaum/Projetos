package br.com.api.banco.model.dto;

import br.com.api.banco.model.Cliente;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.stream.Collectors;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ClienteDetalhesDto {
    private String nome;
    private String cpf;
    private PoupancaDto poupanca;
    private CorrenteDto corrente;

    public ClienteDetalhesDto(Cliente cliente){
        this.nome = cliente.getNome();
        this.cpf = cliente.getCpf();
        PoupancaDto poupancaDto = new PoupancaDto(cliente.getPoupanca());
        this.poupanca = poupancaDto;
        CorrenteDto correnteDto = new CorrenteDto(cliente.getCorrente());
        this.corrente = correnteDto;
    }

    public static List<ClienteDetalhesDto> convert(List<Cliente> clientes){
        return clientes.stream().map(ClienteDetalhesDto::new).collect(Collectors.toList());
    }
}
