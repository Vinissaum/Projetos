package br.com.api.banco.model.dto;

import br.com.api.banco.model.Corrente;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.stream.Collectors;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CorrenteDto {
    private String agencia;
    private String conta;
    private float saldo;

    public CorrenteDto(Corrente corrente){
        this.agencia = corrente.getAgencia();
        this.conta = corrente.getConta();
        this.saldo = corrente.getSaldo();
    }

    public static List<CorrenteDto> convert(List<Corrente> correntes){
        return correntes.stream().map(CorrenteDto::new).collect(Collectors.toList());
    }
}
