package br.com.api.banco.service.exceptions;

public class ClienteException extends RuntimeException{
    public ClienteException(String msg){
        super(msg);
    }
}
