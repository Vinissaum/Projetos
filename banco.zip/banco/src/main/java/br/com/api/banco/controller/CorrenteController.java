package br.com.api.banco.controller;

import br.com.api.banco.model.Corrente;
import br.com.api.banco.model.dto.CorrenteDto;
import br.com.api.banco.service.CorrenteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/correntes")
public class CorrenteController {
    @Autowired
    private CorrenteService correnteService;

    @GetMapping("/{id}")
    public CorrenteDto listarId(@PathVariable("id") Long id){
        Corrente corrente  = correnteService.findById(id);
        CorrenteDto dto = new CorrenteDto(corrente);
        return dto;
    }

    @GetMapping
    public List<CorrenteDto> listar(){
        List<Corrente> corrente = correnteService.findAll();
        return CorrenteDto.convert(corrente);
    }

    @PostMapping
    public CorrenteDto adicionar(@RequestBody Corrente corrente){
        correnteService.save(corrente);
        CorrenteDto dto = new CorrenteDto(corrente);
        return dto;
    }

    @PutMapping
    public CorrenteDto editar(@RequestBody Corrente corrente){
        correnteService.save(corrente);
        CorrenteDto dto = new CorrenteDto(corrente);
        return dto;
    }

    @DeleteMapping
    public void deletar(@RequestBody Corrente corrente){
        correnteService.delete(corrente);
    }
}
