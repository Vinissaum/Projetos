package br.com.api.banco.service.exceptions;

public class SaldoException extends RuntimeException{
    public SaldoException(String msg){
        super(msg);
    }
}
