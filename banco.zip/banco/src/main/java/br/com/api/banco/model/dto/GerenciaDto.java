package br.com.api.banco.model.dto;

import br.com.api.banco.model.Gerencia;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.stream.Collectors;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class GerenciaDto {
    private ClienteDto cliente;
    private PoupancaDto poupanca;
    private CorrenteDto corrente;
    private SimulacaoDto simulacao;

    public GerenciaDto(Gerencia gerencia){
        ClienteDto clienteDto = new ClienteDto(gerencia.getCliente());
        this.cliente = clienteDto;
        PoupancaDto poupancaDto = new PoupancaDto(gerencia.getPoupanca());
        this.poupanca = poupancaDto;
        CorrenteDto correnteDto = new CorrenteDto(gerencia.getCorrente());
        this.corrente = correnteDto;
        SimulacaoDto simulacaoDto = new SimulacaoDto(gerencia.getSimulacao());
        this.simulacao = simulacaoDto;
    }

    public static List<GerenciaDto> convert(List<Gerencia> gerencia){
        return gerencia.stream().map(GerenciaDto::new).collect(Collectors.toList());
    }
}
