package br.com.api.banco.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
public class Simulacao {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private int tempo;
    private float saldoAnterior;
    private float novoSaldo;
    @OneToOne(cascade = CascadeType.ALL)
    private Poupanca poupanca;
    @OneToOne(cascade = CascadeType.ALL)
    private Gerencia gerencia;
}
