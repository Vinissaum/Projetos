package br.com.api.banco.model.dto;

import br.com.api.banco.model.Poupanca;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.stream.Collectors;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PoupancaDto {
    private String agencia;
    private String conta;
    private float saldo;

    public PoupancaDto(Poupanca poupanca){
        this.agencia = poupanca.getAgencia();
        this.conta = poupanca.getConta();
        this.saldo = poupanca.getSaldo();
    }

    public static List<PoupancaDto> convert(List<Poupanca> poupancas){
        return poupancas.stream().map(PoupancaDto::new).collect(Collectors.toList());
    }
}
