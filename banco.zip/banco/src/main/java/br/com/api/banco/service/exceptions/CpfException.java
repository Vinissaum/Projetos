package br.com.api.banco.service.exceptions;

public class CpfException extends RuntimeException{
    public CpfException(String msg){
        super(msg);
    }
}
