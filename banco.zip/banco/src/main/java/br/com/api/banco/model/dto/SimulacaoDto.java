package br.com.api.banco.model.dto;

import br.com.api.banco.model.Simulacao;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.stream.Collectors;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SimulacaoDto {
    private int meses;
    private float saldo;
    private float novoSaldo;

    public SimulacaoDto(Simulacao simulacao){
        this.meses = simulacao.getTempo();
        this.saldo = simulacao.getSaldoAnterior();
        this.novoSaldo = simulacao.getNovoSaldo();
    }

    public static List<SimulacaoDto> convert(List<Simulacao> simulacao){
        return simulacao.stream().map(SimulacaoDto::new).collect(Collectors.toList());
    }
}
