package br.com.api.banco.repository;

import br.com.api.banco.model.Corrente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CorrenteRepository extends JpaRepository<Corrente, Long> {
}
