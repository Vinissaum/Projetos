package br.com.api.banco.service;

import br.com.api.banco.model.*;
import br.com.api.banco.repository.GerenciaRepository;
import br.com.api.banco.service.exceptions.ClienteException;
import br.com.api.banco.service.exceptions.EntityException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GerenciaService {
    @Autowired
    private GerenciaRepository gerenciaRepository;
    @Autowired
    private ClienteService clienteService;
    @Autowired
    private PoupancaService poupancaService;
    @Autowired
    private CorrenteService correnteService;
    @Autowired
    private SimulacaoService simulacaoService;

    public Gerencia findById(Long id){
        return gerenciaRepository.findById(id).orElseThrow(
                () -> new EntityException("O id "+id+" não foi encontrado")
        );
    }

    public List<Gerencia> findAll(){
        return gerenciaRepository.findAll();
    }

    public Gerencia save(Gerencia gerencia){
        if(gerencia.getCliente() != null){
            Cliente cliente = gerencia.getCliente();
            cliente.setPoupanca(gerencia.getPoupanca());
            cliente.setCorrente(gerencia.getCorrente());
            cliente.setGerencia(gerencia);
            clienteService.save(cliente);
            if(gerencia.getPoupanca() != null ){
                Poupanca poupanca = gerencia.getPoupanca();
                poupanca.setCliente(gerencia.getCliente());
                poupanca.setSimulacao(gerencia.getSimulacao());
                poupanca.setGerencia(gerencia);
                poupancaService.save(poupanca);
            }
            if(gerencia.getSimulacao() != null && gerencia.getPoupanca() != null){
                Simulacao simulacao = gerencia.getSimulacao();
                Poupanca poupanca = gerencia.getPoupanca();
                simulacao.setSaldoAnterior(poupanca.getSaldo());
                simulacaoService.save(simulacao);
            }
            else{
                gerencia.setSimulacao(null);
            }
            if(gerencia.getCorrente() != null){
                Corrente corrente = gerencia.getCorrente();
                corrente.setCliente(gerencia.getCliente());
                corrente.setGerencia(gerencia);
                correnteService.save(corrente);
            }

            return gerenciaRepository.save(gerencia);
        }
        throw new ClienteException("O cliente não pode estar em branco");
    }

    public void delete(Gerencia gerencia){
        gerenciaRepository.delete(gerencia);
    }
}
