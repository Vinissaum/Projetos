package br.com.api.banco.service.exceptions;

public class TempoException extends RuntimeException{
    public TempoException(String msg){
        super(msg);
    }
}
