package br.com.api.banco.controller;

import br.com.api.banco.model.Cliente;
import br.com.api.banco.model.dto.ClienteDetalhesDto;
import br.com.api.banco.model.dto.ClienteDto;
import br.com.api.banco.service.ClienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/clientes")
public class ClienteController {
    @Autowired
    private ClienteService clienteService;

    @GetMapping("/{id}")
    public ClienteDetalhesDto listarDetalhes(@PathVariable("id") Long id){
        Cliente cliente = clienteService.findById(id);
        ClienteDetalhesDto dto = new ClienteDetalhesDto(cliente);
        return dto;
    }

    @GetMapping
    public List<ClienteDto> listar(){
        List<Cliente> cliente = clienteService.findAll();
        return ClienteDto.convert(cliente);
    }

    @PostMapping
    public ClienteDetalhesDto adicionar(@RequestBody Cliente cliente){
        clienteService.save(cliente);
        ClienteDetalhesDto dto = new ClienteDetalhesDto(cliente);
        return dto;
    }

    @PutMapping
    public ClienteDetalhesDto editar(@RequestBody Cliente cliente){
        clienteService.save(cliente);
        ClienteDetalhesDto dto = new ClienteDetalhesDto(cliente);
        return dto;
    }

    @DeleteMapping
    public void deletar(@RequestBody Cliente cliente){
        clienteService.delete(cliente);
    }
}
