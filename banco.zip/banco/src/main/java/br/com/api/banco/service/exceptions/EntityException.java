package br.com.api.banco.service.exceptions;

public class EntityException extends RuntimeException{
    public EntityException(String msg){
        super(msg);
    }
}
