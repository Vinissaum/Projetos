package br.com.api.banco.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
public class Gerencia {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
    @OneToOne(cascade = CascadeType.ALL)
    private Cliente cliente;
    @OneToOne(cascade = CascadeType.ALL)
    private Corrente corrente;
    @OneToOne(cascade = CascadeType.ALL)
    private Poupanca poupanca;
    @OneToOne(cascade = CascadeType.ALL)
    private Simulacao simulacao;
}
