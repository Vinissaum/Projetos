package br.com.api.banco.controller;

import br.com.api.banco.model.Simulacao;
import br.com.api.banco.model.dto.SimulacaoDto;
import br.com.api.banco.service.SimulacaoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("simulacoes")
public class SimulacaoController {
    @Autowired
    private SimulacaoService simulacaoService;

    @GetMapping("/{id}")
    public SimulacaoDto listarId(@PathVariable("id") Long id){
        Simulacao simulacao = simulacaoService.findById(id);
        SimulacaoDto dto = new SimulacaoDto(simulacao);
        return dto;
    }

    @GetMapping
    public List<SimulacaoDto> listar(){
        List<Simulacao> simulacao = simulacaoService.findAll();
        return SimulacaoDto.convert(simulacao);
    }

    @PostMapping
    public SimulacaoDto adicionar(@RequestBody Simulacao simulacao){
        simulacaoService.save(simulacao);
        SimulacaoDto dto = new SimulacaoDto(simulacao);
        return dto;
    }

    @PutMapping
    public SimulacaoDto editar(@RequestBody Simulacao simulacao){
        simulacaoService.save(simulacao);
        SimulacaoDto dto = new SimulacaoDto(simulacao);
        return dto;
    }

    @DeleteMapping
    public void deletar(@RequestBody Simulacao simulacao){
        simulacaoService.delete(simulacao);
    }
}
