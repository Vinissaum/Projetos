package br.com.api.banco.service;

import br.com.api.banco.model.Simulacao;
import br.com.api.banco.repository.SimulacaoRepository;
import br.com.api.banco.service.exceptions.EntityException;
import br.com.api.banco.service.exceptions.TempoException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SimulacaoService {
    @Autowired
    private SimulacaoRepository simulacaoRepository;

    public Simulacao findById(Long id){
        return simulacaoRepository.findById(id).orElseThrow(
                () -> new EntityException("O id "+id+" não foi encontrado")
        );
    }

    public List<Simulacao> findAll(){
        return simulacaoRepository.findAll();
    }

    public Simulacao save(Simulacao simulacao){
        if(simulacao.getTempo() > 0){
            int mes = simulacao.getTempo();
            float valorInicial = simulacao.getSaldoAnterior();
            float valorRendimento = valorInicial;
            for(int i = 0; i < mes; i++){
                valorRendimento+=(valorRendimento*0.007f);
            }
            simulacao.setNovoSaldo(valorRendimento);

            return simulacaoRepository.save(simulacao);
        }
        throw new TempoException("A quantidade de meses da simulação deve ser maior que zero");
    }

    public void delete(Simulacao simulacao){
        simulacaoRepository.delete(simulacao);
    }
}