package br.com.api.banco.controller;

import br.com.api.banco.model.Poupanca;
import br.com.api.banco.model.dto.PoupancaDetalhesDto;
import br.com.api.banco.model.dto.PoupancaDto;
import br.com.api.banco.service.PoupancaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/poupanca")
public class PoupancaController {
    @Autowired
    private PoupancaService poupancaService;

    @GetMapping("/{id}")
    public PoupancaDetalhesDto listarDetalhes(@PathVariable("id") Long id){
        Poupanca poupanca = poupancaService.findById(id);
        PoupancaDetalhesDto dto = new PoupancaDetalhesDto(poupanca);
        return dto;
    }

    @GetMapping
    public List<PoupancaDto> listar(){
        List<Poupanca> poupanca = poupancaService.findAll();
        return PoupancaDto.convert(poupanca);
    }

    @PostMapping
    public PoupancaDetalhesDto adicionar(@RequestBody Poupanca poupanca){
        poupancaService.save(poupanca);
        PoupancaDetalhesDto dto = new PoupancaDetalhesDto(poupanca);
        return dto;
    }

    @PutMapping
    public PoupancaDetalhesDto editar(@RequestBody Poupanca poupanca){
        poupancaService.save(poupanca);
        PoupancaDetalhesDto dto = new PoupancaDetalhesDto(poupanca);
        return dto;
    }

    @DeleteMapping
    public void deletar(@RequestBody Poupanca poupanca){
        poupancaService.delete(poupanca);
    }
}
