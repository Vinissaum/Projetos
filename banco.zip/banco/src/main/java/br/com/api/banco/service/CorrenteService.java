package br.com.api.banco.service;

import br.com.api.banco.model.Corrente;
import br.com.api.banco.repository.CorrenteRepository;
import br.com.api.banco.service.exceptions.EntityException;
import br.com.api.banco.service.exceptions.SaldoException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CorrenteService {
    @Autowired
    private CorrenteRepository correnteRepository;

    public static int getRandomIntegerBetweenRange(double min, double max){
        double x = (Math.random()*((max-min)+1))+min;

        return (int)x;
    }

    public Corrente findById(Long id){
        return correnteRepository.findById(id).orElseThrow(
                () -> new EntityException("O id "+id+" não foi encontrado")
        );
    }

    public List<Corrente> findAll(){
        return correnteRepository.findAll();
    }

    public Corrente save(Corrente corrente){
        if(corrente.getSaldo() > 0){
            String conta = "";
            for(int i = 0; i < 6; i++){
                conta += getRandomIntegerBetweenRange(0, 9);
            }
            conta+="-";
            conta+=getRandomIntegerBetweenRange(0, 9);
            String agencia = "";
            for(int i = 0; i<5; i++){
                agencia += getRandomIntegerBetweenRange(0, 9);
            }
            corrente.setAgencia(agencia);
            corrente.setConta(conta);

            return correnteRepository.save(corrente);
        }
        throw new SaldoException("O saldo não pode ser menor que zero");
    }

    public void delete(Corrente corrente){
        correnteRepository.delete(corrente);
    }
}
