package br.com.api.banco.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
public class Cliente implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private String nome;
    private String cpf;
    @OneToOne(cascade = CascadeType.ALL)
    private Poupanca poupanca;
    @OneToOne(cascade = CascadeType.ALL)
    private Corrente corrente;
    @OneToOne(cascade = CascadeType.ALL)
    private Gerencia gerencia;
}
