package br.com.api.banco.controller;

import br.com.api.banco.model.Corrente;
import br.com.api.banco.model.Gerencia;
import br.com.api.banco.model.dto.GerenciaDto;
import br.com.api.banco.service.GerenciaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/gerencia")
public class GerenciaController {
    @Autowired
    private GerenciaService gerenciaService;

    @GetMapping("/{id")
    public GerenciaDto listarId(@PathVariable("id") Long id){
        Gerencia gerencia = gerenciaService.findById(id);
        GerenciaDto dto = new GerenciaDto(gerencia);
        return dto;
    }

    @GetMapping
    public List<GerenciaDto> listar(){
        List<Gerencia> gerencia = gerenciaService.findAll();
        return GerenciaDto.convert(gerencia);
    }

    @PostMapping
    public GerenciaDto adicionar(@RequestBody Gerencia gerencia){
        gerenciaService.save(gerencia);
        GerenciaDto dto = new GerenciaDto(gerencia);
        return dto;
    }

    @PutMapping
    public GerenciaDto editar(@RequestBody Gerencia gerencia){
        gerenciaService.save(gerencia);
        GerenciaDto dto = new GerenciaDto(gerencia);
        return dto;
    }

    @DeleteMapping
    public void deletar(@RequestBody Gerencia gerencia){
        gerenciaService.delete(gerencia);
    }
}
