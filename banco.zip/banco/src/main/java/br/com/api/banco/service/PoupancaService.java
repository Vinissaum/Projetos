package br.com.api.banco.service;

import br.com.api.banco.model.Poupanca;
import br.com.api.banco.repository.PoupancaRepository;
import br.com.api.banco.service.exceptions.EntityException;
import br.com.api.banco.service.exceptions.SaldoException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PoupancaService {
    @Autowired
    private PoupancaRepository poupancaRepository;

    public static int getRandomIntegerBetweenRange(double min, double max){
        double x = (Math.random()*((max-min)+1))+min;
        return (int)x;
    }

    public Poupanca findById(Long id){
        return poupancaRepository.findById(id).orElseThrow(
                () -> new EntityException("O id "+id+" não foi encontrado")
        );
    }

    public List<Poupanca> findAll(){
        return poupancaRepository.findAll();
    }

    public Poupanca save(Poupanca poupanca){
        if(poupanca.getSaldo() > 0){
            String conta = "";
            for(int i = 0; i < 6; i++){
                conta += getRandomIntegerBetweenRange(0 , 9);
            }
            conta += "-";
            conta += getRandomIntegerBetweenRange(0, 9);

            String agencia = "";
            for(int i = 0; i<5; i++){
                agencia+=getRandomIntegerBetweenRange(0,9);
            }
            poupanca.setAgencia(agencia);
            poupanca.setConta(conta);

            return poupancaRepository.save(poupanca);
        }
        throw new SaldoException("O saldo não pode ser negativo");
    }

    public void delete(Poupanca poupanca){
        poupancaRepository.delete(poupanca);
    }
}
