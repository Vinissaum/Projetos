package br.com.api.banco.service.exceptions;

public class NomeException extends RuntimeException{
    public NomeException(String msg){
        super(msg);
    }
}
