package br.com.api.loja.service;

import br.com.api.loja.model.Cliente;
import br.com.api.loja.repository.ClienteRepository;
import br.com.api.loja.service.exceptions.CpfException;
import br.com.api.loja.service.exceptions.ENFException;
import br.com.api.loja.service.exceptions.NomeException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ClienteService {
    @Autowired
    private ClienteRepository clienteRepository;

    public Cliente findById(Long id){
        return clienteRepository.findById(id).orElseThrow(
                () -> new ENFException("O ID "+ id +" não foi encontrado.")
        );
    }

    public List<Cliente> findAll(){
        return clienteRepository.findAll();
    }

    public Cliente save(Cliente cliente){
        if(cliente.getNome() != null){
            if(cliente.getCpf().length() == 11){
                return clienteRepository.save(cliente);
            }
            throw new CpfException("CPF inválido");
        }
        throw new NomeException("O nome não pode estar em branco");
    }

    public void delete(Cliente cliente){
        clienteRepository.delete(cliente);
    }
}
