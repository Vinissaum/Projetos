package br.com.api.loja.model.dto;

import br.com.api.loja.model.Cliente;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ClienteDetalhesDto {
    private String nome;
    private String cpf;
    private List<ProdutoDto> produtos = new ArrayList();
    private ParcelamentoDto parcelamento;

    public ClienteDetalhesDto(Cliente cliente){
        this.nome = cliente.getNome();
        this.cpf = cliente.getCpf();
        cliente.getProdutos().forEach(p -> {
            ProdutoDto produtoDto = new ProdutoDto(p);
            produtos.add(produtoDto);
        });
        ParcelamentoDto parcelamentoDto = new ParcelamentoDto(cliente.getParcelamento());
        this.parcelamento = parcelamentoDto;
    }

    public static List<ClienteDetalhesDto> convert(List<Cliente> clientes){
        return clientes.stream().map(ClienteDetalhesDto::new).collect(Collectors.toList());
    }
}
