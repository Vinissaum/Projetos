package br.com.api.loja.service;

import br.com.api.loja.model.Produto;
import br.com.api.loja.repository.ProdutoRepository;
import br.com.api.loja.service.exceptions.ENFException;
import br.com.api.loja.service.exceptions.NomeException;
import br.com.api.loja.service.exceptions.PrecoException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProdutoService {
    @Autowired
    private ProdutoRepository produtoRepository;

    public Produto findById(Long id){
        return produtoRepository.findById(id).orElseThrow(
                () -> new ENFException("O id "+ id +" não foi encontrado")
        );
    }

    public List<Produto> findAll(){
        return produtoRepository.findAll();
    }

    public Produto save(Produto produto){
        if(produto.getNome() != null){
            if(produto.getPreco() >= 0){
                return produtoRepository.save(produto);
            }
            throw new PrecoException("O preco do produto não pode ser menor que zero");
        }
        throw new NomeException("O nome do produto não pode estar em branco");
    }

    public void delete(Produto produto){
        produtoRepository.delete(produto);
    }
}
