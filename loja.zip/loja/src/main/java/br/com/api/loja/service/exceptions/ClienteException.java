package br.com.api.loja.service.exceptions;

public class ClienteException extends RuntimeException{
    public ClienteException(String msg){
        super(msg);
    }
}
