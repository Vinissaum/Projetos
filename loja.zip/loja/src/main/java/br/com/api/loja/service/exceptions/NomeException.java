package br.com.api.loja.service.exceptions;

public class NomeException extends RuntimeException{
    public NomeException(String msg){
        super(msg);
    }
}
