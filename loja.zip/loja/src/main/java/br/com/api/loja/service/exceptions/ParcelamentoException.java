package br.com.api.loja.service.exceptions;

public class ParcelamentoException extends RuntimeException{
    public ParcelamentoException(String msg){
        super(msg);
    }
}
