package br.com.api.loja.model;

import lombok.AllArgsConstructor;
import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor
@Entity
public class Cliente implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    private String nome;
    private String cpf;
    @OneToMany(cascade = CascadeType.ALL)
    private List<Produto> produtos;
    @OneToOne(cascade = CascadeType.ALL)
    private Parcelamento parcelamento;
    @OneToOne(cascade = CascadeType.ALL)
    private Venda venda;

    public Cliente(){
        this.produtos = new ArrayList();
    }
}
