package br.com.api.loja.model;

import lombok.AllArgsConstructor;
import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Entity
@Data
@AllArgsConstructor
public class Venda implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
    @OneToOne(cascade = CascadeType.ALL)
    private Cliente cliente;
    @OneToOne(cascade = CascadeType.ALL)
    private Parcelamento parcelamento;
    @OneToMany(cascade = CascadeType.ALL)
    private List<Produto> produtos;

    public Venda(){
        this.produtos = new ArrayList();
    }
}
