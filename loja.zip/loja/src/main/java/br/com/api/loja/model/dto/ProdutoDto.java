package br.com.api.loja.model.dto;

import br.com.api.loja.model.Produto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.stream.Collectors;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProdutoDto {
    private String nome;
    private float preco;

    public ProdutoDto(Produto produto){
        this.nome = produto.getNome();
        this.preco = produto.getPreco();
    }

    public static List<ProdutoDto> convert(List<Produto> produtos){
        return produtos.stream().map(ProdutoDto::new).collect(Collectors.toList());
    }
}
