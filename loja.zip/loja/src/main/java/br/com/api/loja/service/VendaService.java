package br.com.api.loja.service;

import br.com.api.loja.model.Cliente;
import br.com.api.loja.model.Parcelamento;
import br.com.api.loja.model.Produto;
import br.com.api.loja.model.Venda;
import br.com.api.loja.repository.VendaRepository;
import br.com.api.loja.service.exceptions.ClienteException;
import br.com.api.loja.service.exceptions.ENFException;
import br.com.api.loja.service.exceptions.ParcelamentoException;
import br.com.api.loja.service.exceptions.ProdutoException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class VendaService {
    @Autowired
    private VendaRepository vendaRepository;
    @Autowired
    private ClienteService clienteService;
    @Autowired
    private ProdutoService produtoService;
    @Autowired
    private ParcelamentoService parcelamentoService;

    public Venda findById(Long id){
        return vendaRepository.findById(id).orElseThrow(
                () -> new ENFException("O id "+id+" não foi encontrado")
        );
    }

    public List<Venda> findAll(){
        return vendaRepository.findAll();
    }

    public Venda save(Venda venda){
        if(venda.getCliente() != null){
            int num = venda.getProdutos().size();
            if(num != 0){
                if(venda.getParcelamento() != null){
                    Parcelamento parcelamento = venda.getParcelamento();
                    float total = 0;
                    for(Produto p:venda.getProdutos()){
                        total = total + p.getPreco();
                    }
                    parcelamento.setValor(total);
                    parcelamento.setCliente(venda.getCliente());
                    parcelamentoService.save(parcelamento);
                    Cliente cliente = venda.getCliente();
                    cliente.setParcelamento(venda.getParcelamento());
                    List<Produto> produtos = new ArrayList();
                    venda.getProdutos().forEach(p -> {
                        produtos.add(p);
                        produtoService.save(p);
                    });
                    cliente.setProdutos(produtos);
                    clienteService.save(cliente);
                    return vendaRepository.save(venda);
                }
                throw new ParcelamentoException("O parcelamento não pode estar vazio");
            }
            throw new ProdutoException("O produto não pode estar vazio");
        }
        throw new ClienteException("O cliente não pode estar em branco");
    }

    public void delete(Venda venda){
        vendaRepository.delete(venda);
    }
}
