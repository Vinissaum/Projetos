package br.com.api.loja.service.exceptions;

public class ParcelaException extends RuntimeException{
    public ParcelaException(String msg){
        super(msg);
    }
}
