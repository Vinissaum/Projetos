package br.com.api.loja.model.dto;

import br.com.api.loja.model.Parcelamento;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.stream.Collectors;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ParcelamentoDto {
    private int parcelas;
    private float valor;
    private float valorJuros;

    public ParcelamentoDto(Parcelamento parcelamento){
        this.parcelas = parcelamento.getParcelas();
        this.valor = parcelamento.getValor();
        this.valorJuros = parcelamento.getValorJuros();
    }

    public static List<ParcelamentoDto> convert(List<Parcelamento> parcelamentos){
        return parcelamentos.stream().map(ParcelamentoDto::new).collect(Collectors.toList());
    }
}
