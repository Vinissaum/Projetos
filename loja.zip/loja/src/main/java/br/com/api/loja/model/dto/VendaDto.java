package br.com.api.loja.model.dto;

import br.com.api.loja.model.Venda;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class VendaDto {
    private ClienteDto cliente;
    private List<ProdutoDto> produtos = new ArrayList();
    private ParcelamentoDto parcelamento;

    public VendaDto(Venda venda){
        ClienteDto clienteDto = new ClienteDto(venda.getCliente());
        this.cliente = clienteDto;
        venda.getProdutos().forEach(p -> {
            ProdutoDto produtoDto = new ProdutoDto(p);
            produtos.add(produtoDto);
        });
        ParcelamentoDto parcelamentoDto = new ParcelamentoDto(venda.getParcelamento());
        this.parcelamento = parcelamentoDto;
    }

    public static List<VendaDto> convert(List<Venda> vendas){
        return vendas.stream().map(VendaDto::new).collect(Collectors.toList());
    }
}
