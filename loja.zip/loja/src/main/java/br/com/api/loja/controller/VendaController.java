package br.com.api.loja.controller;

import br.com.api.loja.model.Venda;
import br.com.api.loja.model.dto.VendaDto;
import br.com.api.loja.service.VendaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/vendas")
public class VendaController {
    @Autowired
    private VendaService vendaService;

    @GetMapping
    public List<VendaDto> listar(){
        List<Venda> vendas = vendaService.findAll();
        return VendaDto.convert(vendas);
    }

    @GetMapping("/{id}")
    public VendaDto listarId(@PathVariable("id") Long id){
        Venda venda = vendaService.findById(id);
        VendaDto dto = new VendaDto(venda);
        return dto;
    }

    @PostMapping
    public VendaDto adicionar(@RequestBody Venda venda){
        vendaService.save(venda);
        VendaDto dto = new VendaDto(venda);
        return dto;
    }

    @PutMapping
    public VendaDto editar(@RequestBody Venda venda){
        vendaService.save(venda);
        VendaDto dto = new VendaDto(venda);
        return dto;
    }

    @DeleteMapping
    public void deletar(@RequestBody Venda venda){
        vendaService.delete(venda);
    }
}
