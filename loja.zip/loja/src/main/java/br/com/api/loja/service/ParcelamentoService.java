package br.com.api.loja.service;

import br.com.api.loja.model.Parcelamento;
import br.com.api.loja.repository.ParcelamentoRepository;
import br.com.api.loja.service.exceptions.ENFException;
import br.com.api.loja.service.exceptions.ParcelaException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ParcelamentoService {
    @Autowired
    private ParcelamentoRepository parcelamentoRepository;

    public Parcelamento findById(Long id){
        return parcelamentoRepository.findById(id).orElseThrow(
                () -> new ENFException("O id "+ id +" não foi encontrado")
        );
    }

    public List<Parcelamento> findAll(){
        return parcelamentoRepository.findAll();
    }

    public Parcelamento save(Parcelamento parcelamento){
        if(parcelamento.getParcelas() > 0){
            if(parcelamento.getParcelas() >= 6){
                int parcelas = parcelamento.getParcelas();
                float valor = parcelamento.getValor();
                float total = 0;
                float valorParcela = valor/parcelas;
                for(int i=0; i<parcelas;i++){
                    valorParcela = valorParcela+(valorParcela*2)/100;
                    total = total+valorParcela;
                }
                parcelamento.setValorJuros(total);
                return parcelamentoRepository.save(parcelamento);
            }
            parcelamento.setValorJuros(parcelamento.getValor());
            return parcelamentoRepository.save(parcelamento);
        }
        throw new ParcelaException("O numero de parcelas deve ser maior que zero");
    }

    public void delete(Parcelamento parcelamento){
        parcelamentoRepository.delete(parcelamento);
    }
}
