package br.com.api.loja.controller;

import br.com.api.loja.model.Parcelamento;
import br.com.api.loja.model.dto.ParcelamentoDto;
import br.com.api.loja.service.ParcelamentoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/parcelamentos")
public class ParcelamentoController {
    @Autowired
    private ParcelamentoService parcelamentoService;

    @GetMapping
    public List<ParcelamentoDto> listar(){
        List<Parcelamento> parcelamentos = parcelamentoService.findAll();
        return ParcelamentoDto.convert(parcelamentos);
    }

    @GetMapping("/{id}")
    public ParcelamentoDto listarId(@PathVariable("id") Long id){
        Parcelamento parcelamento = parcelamentoService.findById(id);
        ParcelamentoDto dto = new ParcelamentoDto(parcelamento);
        return dto;
    }

    @PostMapping
    public ParcelamentoDto adicionar(@RequestBody Parcelamento parcelamento){
        parcelamentoService.save(parcelamento);
        ParcelamentoDto dto = new ParcelamentoDto(parcelamento);
        return dto;
    }

    @PutMapping
    public ParcelamentoDto editar(@RequestBody Parcelamento parcelamento){
        parcelamentoService.save(parcelamento);
        ParcelamentoDto dto = new ParcelamentoDto(parcelamento);
        return dto;
    }

    @DeleteMapping
    public void deletar(@RequestBody Parcelamento parcelamento){
        parcelamentoService.delete(parcelamento);
    }
}
