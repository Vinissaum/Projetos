package br.com.api.loja.controller.exceptions;

import br.com.api.loja.service.exceptions.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import javax.servlet.http.HttpServletRequest;
import java.time.Instant;

@ControllerAdvice
public class ControllerExceptionHandler {
    @ExceptionHandler
    public ResponseEntity<StandardError> entityNotFound(ENFException e, HttpServletRequest request) {
        StandardError se = new StandardError();
        se.setTimestamp(Instant.now());
        se.setStatus(HttpStatus.NOT_FOUND.value());
        se.setError("Recurso não encontrado");
        se.setMessage(e.getMessage());
        se.setPath(request.getRequestURI());
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(se);
    }

    @ExceptionHandler
    public ResponseEntity<StandardError> Cliente(ClienteException e, HttpServletRequest request) {
        StandardError se = new StandardError();
        se.setTimestamp(Instant.now());
        se.setStatus(HttpStatus.BAD_REQUEST.value());
        se.setError("Cliente em branco");
        se.setMessage(e.getMessage());
        se.setPath(request.getRequestURI());
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(se);
    }

    @ExceptionHandler
    public ResponseEntity<StandardError> Cpf(CpfException e, HttpServletRequest request) {
        StandardError se = new StandardError();
        se.setTimestamp(Instant.now());
        se.setStatus(HttpStatus.BAD_REQUEST.value());
        se.setError("CPF inválido");
        se.setMessage(e.getMessage());
        se.setPath(request.getRequestURI());
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(se);
    }

    @ExceptionHandler
    public ResponseEntity<StandardError> Nome(NomeException e, HttpServletRequest request) {
        StandardError se = new StandardError();
        se.setTimestamp(Instant.now());
        se.setStatus(HttpStatus.BAD_REQUEST.value());
        se.setError("Nome em branco");
        se.setMessage(e.getMessage());
        se.setPath(request.getRequestURI());
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(se);
    }

    @ExceptionHandler
    public ResponseEntity<StandardError> Parcela(ParcelaException e, HttpServletRequest request) {
        StandardError se = new StandardError();
        se.setTimestamp(Instant.now());
        se.setStatus(HttpStatus.BAD_REQUEST.value());
        se.setError("Parcela menor que 1");
        se.setMessage(e.getMessage());
        se.setPath(request.getRequestURI());
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(se);
    }

    @ExceptionHandler
    public ResponseEntity<StandardError> Parcelamento(ParcelamentoException e, HttpServletRequest request) {
        StandardError se = new StandardError();
        se.setTimestamp(Instant.now());
        se.setStatus(HttpStatus.BAD_REQUEST.value());
        se.setError("Parcelamento não inserido");
        se.setMessage(e.getMessage());
        se.setPath(request.getRequestURI());
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(se);
    }

    @ExceptionHandler
    public ResponseEntity<StandardError> Preco(PrecoException e, HttpServletRequest request) {
        StandardError se = new StandardError();
        se.setTimestamp(Instant.now());
        se.setStatus(HttpStatus.BAD_REQUEST.value());
        se.setError("Preco menor que zero");
        se.setMessage(e.getMessage());
        se.setPath(request.getRequestURI());
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(se);
    }

    @ExceptionHandler
    public ResponseEntity<StandardError> Produto(ProdutoException e, HttpServletRequest request) {
        StandardError se = new StandardError();
        se.setTimestamp(Instant.now());
        se.setStatus(HttpStatus.BAD_REQUEST.value());
        se.setError("Produto não inserido");
        se.setMessage(e.getMessage());
        se.setPath(request.getRequestURI());
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(se);
    }
}
