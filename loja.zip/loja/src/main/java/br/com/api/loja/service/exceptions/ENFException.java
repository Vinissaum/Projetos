package br.com.api.loja.service.exceptions;

public class ENFException extends RuntimeException{
    public ENFException(String msg){
        super(msg);
    }
}
