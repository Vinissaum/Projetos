package br.com.api.loja.service.exceptions;

public class ProdutoException extends RuntimeException{
    public ProdutoException(String msg){
        super(msg);
    }
}
