package br.com.api.loja.service.exceptions;

public class CpfException extends RuntimeException{
    public CpfException(String msg){
        super(msg);
    }
}
