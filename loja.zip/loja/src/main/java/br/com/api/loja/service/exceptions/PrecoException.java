package br.com.api.loja.service.exceptions;

public class PrecoException extends RuntimeException{
    public PrecoException(String msg){
        super(msg);
    }
}
