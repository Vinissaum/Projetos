package br.com.api.loja.controller;

import br.com.api.loja.model.Cliente;
import br.com.api.loja.model.dto.ClienteDetalhesDto;
import br.com.api.loja.model.dto.ClienteDto;
import br.com.api.loja.service.ClienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/clientes")
public class ClienteController {
    @Autowired
    private ClienteService clienteService;

    @GetMapping
    public List<ClienteDto> listar(){
        List<Cliente> cliente = clienteService.findAll();
        return ClienteDto.convert(cliente);
    }

    @GetMapping("/{id}")
    public ClienteDetalhesDto listarDetalhes(@PathVariable("id") Long id){
        Cliente cliente = clienteService.findById(id);
        ClienteDetalhesDto detalhes = new ClienteDetalhesDto(cliente);
        return detalhes;
    }

    @PostMapping
    public ClienteDetalhesDto adicionar(@RequestBody Cliente cliente){
        clienteService.save(cliente);
        ClienteDetalhesDto detalhes = new ClienteDetalhesDto(cliente);
        return detalhes;
    }

    @PutMapping
    public ClienteDetalhesDto editar(@RequestBody Cliente cliente){
        clienteService.save(cliente);
        ClienteDetalhesDto detalhes = new ClienteDetalhesDto(cliente);
        return detalhes;
    }

    @DeleteMapping
    public void deletar(@RequestBody Cliente cliente){
        clienteService.delete(cliente);
    }
}
