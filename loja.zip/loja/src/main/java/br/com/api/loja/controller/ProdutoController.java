package br.com.api.loja.controller;

import br.com.api.loja.model.Produto;
import br.com.api.loja.model.dto.ProdutoDto;
import br.com.api.loja.service.ProdutoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/produtos")
public class ProdutoController {
    @Autowired
    private ProdutoService produtoService;

    @GetMapping
    public List<ProdutoDto> listar(){
        List<Produto> produtos = produtoService.findAll();
        return ProdutoDto.convert(produtos);
    }

    @GetMapping("/{id}")
    public ProdutoDto listarId(@PathVariable("id") Long id){
        Produto produto = produtoService.findById(id);
        ProdutoDto dto = new ProdutoDto(produto);
        return dto;
    }

    @PostMapping
    public ProdutoDto adicionar(@RequestBody Produto produto){
        produtoService.save(produto);
        ProdutoDto dto = new ProdutoDto(produto);
        return dto;
    }
    @PutMapping
    public ProdutoDto editar(@RequestBody Produto produto){
        produtoService.save(produto);
        ProdutoDto dto = new ProdutoDto(produto);
        return dto;
    }

    @DeleteMapping
    public void deletar(@RequestBody Produto produto){
        produtoService.delete(produto);
    }
}
